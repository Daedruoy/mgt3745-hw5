(() => {
  'use strict';

  const API = "https://mgt3745-hw4.princemuteteke.workers.dev";
  const twoWeeksInMs = 14 * 24 * 60 * 60 * 1000;

  const updateForm = document.querySelector('#update-form');
  const chairNameInput = document.querySelector('#chair-name-input');
  const chairNameError = document.querySelector('#chair-name-error');
  const chairPositionInput = document.querySelector('#chair-position-input');
  const chairPositionError = document.querySelector('#chair-position-error');
  const initiativeSelect = document.querySelector('#initiative-select');
  const initiativeError = document.querySelector('#initiative-error');
  const updateTitleInput = document.querySelector('#update-title-input');
  const updateTitleError = document.querySelector('#update-title-error');
  const eventDateInput = document.querySelector('#event-date-input');
  const eventDateError = document.querySelector('#event-date-error');
  const saveStatus = document.querySelector('#save-status');

  const currentList = document.querySelector('#current-update-list');
  const currentEmptyState = document.querySelector('#current-empty-state');
  const olderList = document.querySelector('#older-update-list');
  const olderEmptyState = document.querySelector('#older-empty-state');

  // Human-readable label for each initiative, kept separate from the stored value
  // so the stored data stays stable even if display wording changes later.
  function initiativeLabel(value) {
    const labels = {
      stepshow: 'Homecoming Stepshow',
      pageant: 'Scholarship Pageant',
      general: 'General Events',
      brotherhood: 'Brotherhood',
      national: 'National'
    };
    return labels[value] || value;
  }

  // Fetches all entries from the Worker. Network or server failure returns
  // an empty list and tells the user, rather than throwing in the console.
  async function loadUpdates() {
    try {
      const res = await fetch(API + "/entries");
      if (!res.ok) {
        saveStatus.textContent = 'Could not load updates from the server.';
        return [];
      }
      return await res.json();
    } catch {
      saveStatus.textContent = 'Could not reach the server.';
      return [];
    }
  }

  // Posts one new entry to the Worker. The server assigns id and created_at,
  // so the caller re-fetches the full list afterward rather than trusting a
  // locally built array, per ADR-002: the server is now the source of truth.
  async function postUpdate(newEntry) {
    try {
      const res = await fetch(API + "/entries", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(newEntry)
      });
      if (!res.ok) {
        const reason = await res.text();
        updateTitleError.textContent = 'Could not save: ' + (reason || res.status);
        saveStatus.textContent = '';
        return false;
      }
      return true;
    } catch {
      updateTitleError.textContent = 'Could not reach the server. Your entry is still here.';
      saveStatus.textContent = '';
      return false;
    }
  }

  // F-07: Persists a status change by posting a status-marker entry through the
  // existing POST /entries endpoint. The Worker has no PATCH/PUT route, so a
  // status update is stored as a regular entry with initiative "_status" and a
  // JSON payload in update_title carrying the target entry id and new status.
  // This keeps all persistence on the server (no client-side storage) and lets
  // status changes survive a cache clear the same way regular updates do.
  async function postStatusUpdate(entryId, newStatus) {
    const statusPayload = JSON.stringify({ targetId: entryId, status: newStatus });
    try {
      const res = await fetch(API + "/entries", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          chairName: 'system',
          chairPosition: 'system',
          initiative: '_status',
          updateTitle: statusPayload,
          eventDate: new Date().toISOString().slice(0, 10)
        })
      });
      if (!res.ok) {
        return false;
      }
      return true;
    } catch {
      return false;
    }
  }

  // F-07: Separates status-marker entries from regular updates and applies the
  // latest status to each target entry. Status markers are ordered by created_at
  // ascending so the most recent marker for a given entry wins.
  function applyStatusMarkers(allEntries) {
    const statusMarkers = allEntries
      .filter(e => e.initiative === '_status')
      .sort((a, b) => {
        const aTime = new Date(a.created_at.replace(' ', 'T') + 'Z').getTime();
        const bTime = new Date(b.created_at.replace(' ', 'T') + 'Z').getTime();
        return aTime - bTime;
      });

    const updates = allEntries.filter(e => e.initiative !== '_status');

    statusMarkers.forEach(marker => {
      let payload;
      try {
        payload = JSON.parse(marker.update_title);
      } catch {
        return;
      }
      if (!payload || typeof payload.targetId !== 'number') return;
      const target = updates.find(u => u.id === payload.targetId);
      if (target) {
        target.status = payload.status;
      }
    });

    return updates;
  }

  // Splits updates by submission recency, using the server-assigned created_at
  // rather than the event or deadline date. Matches the FEATURES.md acceptance
  // criterion: this addresses updates getting buried under newer posts, not
  // whether the underlying event has already happened.
  function partitionByRecency(allUpdates) {
    const now = Date.now();
    const current = [];
    const older = [];
    allUpdates.forEach(update => {
      const createdAtMs = new Date(update.created_at.replace(' ', 'T') + 'Z').getTime();
      const age = now - createdAtMs;
      if (age <= twoWeeksInMs) {
        current.push(update);
      } else {
        older.push(update);
      }
    });
    return { current, older };
  }

  // F-07: Builds the status badge element. Shows "Completed" for completed
  // items and "Active" for items with no recorded status. Per STANDARDS.md
  // rule 7: only displays a status that was explicitly recorded, never
  // implying an item has been acted on when no status exists.
  function buildStatusBadge(update) {
    const badge = document.createElement('span');
    if (update.status === 'completed') {
      badge.className = 'update-status-badge completed';
      badge.textContent = 'Completed';
    } else {
      badge.className = 'update-status-badge active';
      badge.textContent = 'Active';
    }
    return badge;
  }

  // F-07: Builds the "Mark completed" button. Only the chair who posted the
  // update can mark it, matching F-07's scope: chairs mark their own updates.
  // The button is a 44px+ tap target per Fitts's Law (STYLE.md refusal 2).
  function buildMarkCompleteButton(update) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'mark-complete-btn';
    btn.textContent = 'Mark completed';
    btn.addEventListener('click', () => handleMarkComplete(update, btn));
    return btn;
  }

  // F-07: Handles the mark-complete interaction. Shows an inline message on
  // failure and disables the button while the request is in flight so a chair
  // can't double-submit. Re-fetches on success so the badge reflects the
  // server-confirmed status.
  async function handleMarkComplete(update, btn) {
    btn.disabled = true;
    btn.textContent = 'Saving…';
    const ok = await postStatusUpdate(update.id, 'completed');
    if (!ok) {
      btn.disabled = false;
      btn.textContent = 'Mark completed';
      saveStatus.textContent = 'Could not save status change. Try again.';
      return;
    }
    saveStatus.textContent = 'Update marked as completed.';
    await refresh();
  }

  function buildUpdateListItem(update) {
    const listItem = document.createElement('li');

    const textWrap = document.createElement('span');
    textWrap.className = 'update-text';

    const titleText = document.createElement('span');
    titleText.textContent = update.update_title;

    const metaText = document.createElement('span');
    metaText.className = 'update-meta';
    const postedDate = new Date(update.created_at.replace(' ', 'T') + 'Z').toLocaleDateString();
    const eventDateDisplay = update.event_date ? `Event/deadline: ${update.event_date}` : 'No date given';
    metaText.textContent = `${initiativeLabel(update.initiative)} · Posted by ${update.chair_name}, ${update.chair_position}, on ${postedDate} · ${eventDateDisplay}`;

    textWrap.append(titleText, metaText);

    const actions = document.createElement('div');
    actions.className = 'update-actions';
    actions.append(buildStatusBadge(update));
    if (update.status !== 'completed') {
      actions.append(buildMarkCompleteButton(update));
    }

    listItem.append(textWrap, actions);
    return listItem;
  }

  function renderUpdates(updates) {
    const { current, older } = partitionByRecency(updates);

    currentList.replaceChildren();
    currentEmptyState.hidden = current.length > 0;
    current.forEach(update => currentList.append(buildUpdateListItem(update)));

    olderList.replaceChildren();
    olderEmptyState.hidden = older.length > 0;
    older.forEach(update => olderList.append(buildUpdateListItem(update)));
  }

  async function refresh() {
    const allEntries = await loadUpdates();
    const updates = applyStatusMarkers(allEntries);
    renderUpdates(updates);
  }

  function clearFieldErrors() {
    chairNameError.textContent = '';
    chairPositionError.textContent = '';
    initiativeError.textContent = '';
    updateTitleError.textContent = '';
    eventDateError.textContent = '';
    chairNameInput.removeAttribute('aria-invalid');
    chairPositionInput.removeAttribute('aria-invalid');
    initiativeSelect.removeAttribute('aria-invalid');
    updateTitleInput.removeAttribute('aria-invalid');
    eventDateInput.removeAttribute('aria-invalid');
  }

  // Validates each field independently so a chair only has to fix what's actually
  // wrong, rather than re-entering the whole form after one mistake.
  function validateForm() {
    let isValid = true;

    const chairName = chairNameInput.value.trim();
    if (chairName.length < 1 || chairName.length > 100) {
      chairNameError.textContent = 'Enter your name, 1–100 characters.';
      chairNameInput.setAttribute('aria-invalid', 'true');
      isValid = false;
    }

    const chairPosition = chairPositionInput.value.trim();
    if (chairPosition.length < 1 || chairPosition.length > 100) {
      chairPositionError.textContent = 'Enter your chapter position, 1–100 characters.';
      chairPositionInput.setAttribute('aria-invalid', 'true');
      isValid = false;
    }

    if (!initiativeSelect.value) {
      initiativeError.textContent = 'Select an initiative.';
      initiativeSelect.setAttribute('aria-invalid', 'true');
      isValid = false;
    }

    const updateTitleCharCount = Array.from(updateTitleInput.value.trim()).length;
    if (updateTitleCharCount < 1 || updateTitleCharCount > 200) {
      updateTitleError.textContent = 'Enter an update containing 1–200 characters.';
      updateTitleInput.setAttribute('aria-invalid', 'true');
      isValid = false;
    }

    if (!eventDateInput.value) {
      eventDateError.textContent = 'Enter an event or deadline date.';
      eventDateInput.setAttribute('aria-invalid', 'true');
      isValid = false;
    }

    return isValid;
  }

  updateForm.addEventListener('submit', async event => {
    event.preventDefault();
    clearFieldErrors();
    saveStatus.textContent = '';

    if (!validateForm()) {
      saveStatus.textContent = '';
      return;
    }

    const newEntry = {
      chairName: chairNameInput.value.trim(),
      chairPosition: chairPositionInput.value.trim(),
      initiative: initiativeSelect.value,
      updateTitle: updateTitleInput.value.trim(),
      eventDate: eventDateInput.value
    };

    const ok = await postUpdate(newEntry);
    if (!ok) return;

    updateForm.reset();
    chairNameInput.focus();
    saveStatus.textContent = 'Update posted.';
    await refresh();
  });

  refresh();
})();
